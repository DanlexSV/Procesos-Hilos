package ejercicioExamen;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personas p = new Personas();
		
		new EntraChico(p);
		new EntraChica(p);
		
		new SaleChico(p);
		new SaleChica(p);

	}

}
